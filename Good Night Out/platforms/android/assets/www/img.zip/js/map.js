

 var socket = io.connect(window.localStorage.getItem("IP"));
socket.emit('Hello',"Hello");
var map = new google.maps.Map(document.getElementById('mapContent'), {
  zoom: 10,
  center: new google.maps.LatLng(43.33294829188811, 21.893321990966797),
  mapTypeId: google.maps.MapTypeId.ROADMAP
});this.positionL();
socket.on('locationsTransfer', function(locations){

if (locations == null)
{
 locations = [
  ['Bondi Beach', 43.33294829188811, 21.893321990966797, 4],
  ['Coogee Beach', 43.35294829188811, 21.893321990966797, 5],
  ['Cronulla Beach', 43.32294829188811, 21.893321990966797, 3],
  ['Manly Beach', 43.31294829188811, 21.893321990966797, 2],
  ['Maroubra Beach', 43.30294829188811, 21.893321990966797, 1]
];
}


var infowindow = new google.maps.InfoWindow();

var marker, i;

for (i = 0; i < locations.length; i++) {  
  marker = new google.maps.Marker({
    position: new google.maps.LatLng(locations[i].latitude, locations[i].longitude),
    map: map
  });

  google.maps.event.addListener(marker, 'click', (function(marker, i) {
    return function() {
      infowindow.setContent(locations[i].name);
      infowindow.open(map, marker);
    }
  })(marker, i));
}
});

$( "#btnAddLocationFromMap" ).click(function()
{
    alert("Add location clicked");
    var nameVal = $('#locationInput').val();
    var descriptionVal = $('#locDescription').val();
    var latitudeVal = $('#locLatInput').val();
    var longitudeVal = $('#locLngInput').val();

    var locationObject = 
    {
        name: nameVal,
        description: descriptionVal,
        latitude: latitudeVal,
        longitude: longitudeVal
    };"stored"

  
    socket.emit('storeGlobalLocations', locationObject);
    socket.on('locationStoreResult',function(locationStoreResult){alert("locationObject.name")});
});
   function positionL()
   { 
     var options = {
      enableHighAccuracy: true,
      maximumAge: 3600000
   }
   var watchID1 = navigator.geolocation.watchPosition(onSuccess= function (position) {

    Latitude = position.coords.latitude;
    Longitude = position.coords.longitude;

     socket.emit('locationUpdate',"lat:"+Latitude + "\n long:"+Longitude );
}, onError=function(position){ 
     Latitude = position.coords.latitude;
    Longitude = position.coords.longitude;

     socket.emit('locationUpdate',"lat:"+Latitude + "\n long:"+Longitude );

   } , { timeout: 3000 ,enableHighAccuracy: true });

   var watchID = navigator.geolocation.getCurrentPosition(function (position)
   {
     /*$('#mapContent').locationpicker({
             location: {latitude: position.coords.latitude, longitude: position.coords.longitude},   
             radius: 500,
             map:map,
                inputBinding: {
                 latitudeInput: $('#locLatInput'),
                 longitudeInput: $('#locLngInput'),
                 radiusInput: $('#locRadiusInput'),
                locationNameInput: $('#locationInput')
            }
             });*/
                var Circle = null;
                var Radius = 10;

                var StartPosition = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);

                function DrawCircle(Map, Center, Radius) {

                    if (Circle != null) {
                        Circle.setMap(null);
                    }

                    if(Radius > 0) {
                        Radius *= 1609.344;
                        Circle = new google.maps.Circle({
                            center: Center,
                            radius: Radius,
                            strokeColor: "#0000FF",
                            strokeOpacity: 0.35,
                            strokeWeight: 2,
                            fillColor: "#0000FF",
                            fillOpacity: 0.20,
                            map: Map
                        });
                    }
                }

                function SetPosition(Location, Viewport) {
                    Marker.setPosition(Location);
                    if(Viewport){
                        map.fitBounds(Viewport);
                        map.setZoom(map.getZoom() + 2);
                    }
                    else {
                        map.panTo(Location);
                    }
                    Radius = 10;
                    DrawCircle(map, Location, Radius);                   
                   $('#locLatInput').val(Location.lat);
                   $('#locLngInput').val(Location.lng);
                   $('#locRadiusInput').val(10);
                }

                var MapOptions = {
                    zoom: 5,
                    center: StartPosition,
                    mapTypeId: google.maps.MapTypeId.ROADMAP,
                    mapTypeControl: false,
                    disableDoubleClickZoom: true,
                    streetViewControl: false
                };

                            

                var Marker = new google.maps.Marker({
                    position: StartPosition, 
                    map: map, 
                    title: "You are here!",
                    animation: google.maps.Animation.DROP,
                    label: "You are here!",
                    draggable: true,
                });

                google.maps.event.addListener(Marker, "dragend", function(event) {
                    SetPosition(Marker.position);
                });

               /* $("#radius").keyup(function(){
                    google.maps.event.trigger(Marker, "dragend");
                });*/

                DrawCircle(map, StartPosition, Radius);
                SetPosition(Marker.position);
   },
     function (error)
    {
      alert('code: '    + error.code    + '\n' + 'message: ' + error.message + '\n');
    },options);   
}
